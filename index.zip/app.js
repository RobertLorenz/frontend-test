let array;

fetch("https://probafeladat-api.zengo.eu/api/all_states", 
{ headers: { 'token' : '99dbf50e04ee0d561bdcb58ceb9311a8'} }).then(function(response) {
    return response.json();
  }).then(function(data) {
    console.log(data);
    array = data;
    let text = "";
    const megye = document.getElementById("megye");
    if(array && array.data){
    array.data.forEach(el => text += el.name);
    
    }
    megye.innerHTML = text;

  }).catch(function() {
    console.log("Booo");
  });






const varosInput = document.querySelector(".varos-input");
const varosButton = document.querySelector(".varos-button");
const varosList = document.querySelector(".varos-list");

varosButton.addEventListener("click", addVaros);
varosList.addEventListener('click', deleteCheck);

function addVaros(event){
  event.preventDefault();
  const varosDiv = document.createElement("div");
  varosDiv.classList.add("varos");

  const newVaros = document.createElement("li");
  newVaros.innerText = varosInput.value;
  newVaros.classList.add("varos-item");
  varosDiv.appendChild(newVaros);
  //töröl
  const deleteButton = document.createElement("button");
  deleteButton.innerHTML = '<i class="far fa-trash-alt"></i>';
  deleteButton.classList.add("delete-btn");
  varosDiv.appendChild(deleteButton);
  //módosít
  const modButton = document.createElement("button");
  modButton.innerHTML = '<i class="fas fa-check"></i>';
  modButton.classList.add("mod-btn");
  varosDiv.appendChild(modButton);
  //mégse
  const exitButton = document.createElement("button");
  exitButton.innerHTML = '<i class="fas fa-times"t></i>';
  exitButton.classList.add("exit-btn");
  varosDiv.appendChild(exitButton);

  varosList.appendChild(varosDiv);

  varosInput.value = "";
}

function deleteCheck(event){
  const item = event.target;
  if(item.classList[0] === "delete-btn"){
    const varos = item.parentElement; 
    varos.remove();
  }
}

